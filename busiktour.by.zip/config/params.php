<?php
return [
    'admin_email' => 'abzalt@list.ru',
    'app_name' => 'BusIKTour',
    'pagination' => 3,
    'smtp_host' => 'smtp.mail.ru',
    'smtp_port' => '465',
    'smtp_protocol' => 'ssl',
    'smtp_login' => 'abzalt@list.ru',
    'smtp_password' => 'cfkbvf',
    'img_width' => 125,
    'img_height' => 200,
    'gallery_width' => 700,
    'gallery_height' => 1000,
];