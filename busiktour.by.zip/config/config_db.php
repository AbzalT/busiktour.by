<?php
return [
    'dsn' => 'mysql:host=localhost:3306; dbname=busDb;charset=utf8',
    'user' => 'root',
    'password' => '',
];