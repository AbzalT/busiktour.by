<?php

namespace app\models;

use busiktour\base\Model;

class AppModel extends Model {

}