<?php


namespace app\controllers;


class UserController extends AppController {
    public function signupAction() {
        if (!empty($_POST)) {
            $user = new User();
            $data = $_POST;
            $user->load($data);
            if (!$user->validate($data) || !$user->checkUnique()) {
                $user->getErrors();
                $_SESSION['form_data'] = $data;
            } else {
                $user->attributes['password'] = password_hash($user->attributes['password'], PASSWORD_DEFAULT);
                if ($user->save('user')) {
                    $_SESSION['success'] = 'Пользователь зарегистрирован.';
                } else {
                    $_SESSION['error'] = 'Ошибка сохранения пользователя.';
                }
            }
            redirect();
        }
        $this->setMeta('Регистрация');
    }

    public function loginAction() {
        if (!empty($_POST)) {
            $user = new User();
            if ($user->login()) {
                $_SESSION['success'] = 'Вы успешно авторизованы';
            } else {
                $_SESSION['error'] = 'Логин/пароль введены неверно';
            }
//            redirect(PATH, false);
            redirect();
        }
        $this->setMeta('Вход');
    }

    public function logoutAction() {
        if (isset($_SESSION['user'])) unset($_SESSION['user']);
        redirect();
    }

    public function recoveryAction() {
        if (!empty($_POST)) {
            $login = h($_POST['login']);
            $email = h($_POST['email']);
            $user = \R::findOne('user', 'login = ? OR email = ?', [$login, $email]);
            if (!$user) {
                $_SESSION['error'] = 'Пользователь с такими атрибутами не существует.';
            } else {
                UserController::sendRecoveryKey($user->id, $login, $email, time() + 3600);
                $_SESSION['success'] = 'Запрос на востановление пароля отправлен на почту.';
            }
        }

        $this->setMeta('Востановление пароля');
    }

    public function changeAction() {
        if (!empty($_GET)) {
            $recovery = \R::getRow("SELECT * FROM recovery WHERE recovery_key = ?", [h($_GET['key'])]);
            $current_time = time();
//            debug($recovery['ttl']);
//            die();
            if ($current_time < $recovery['ttl']) {
                debug($recovery);
                debug($current_time);
                die();
            }

        }
    }
}