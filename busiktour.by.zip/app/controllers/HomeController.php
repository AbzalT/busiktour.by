<?php

namespace app\controllers;

use busiktour\App;

class HomeController extends AppController {
    public function indexAction(){
        $this->setMeta(App::$app->getProperty('app_name') . ' - Главная страница',
            'Описание ...', 'Ключевые слова');
    }
}