<?php


namespace app\controllers\admin;


class HomeController extends AppController {
    public function indexAction(){
        $this->setMeta('Панель управления');
    }
}